﻿
namespace GoLibrary
{
    partial class UserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.wyp = new System.Windows.Forms.Button();
            this.find = new System.Windows.Forms.Button();
            this.dashboard = new System.Windows.Forms.Button();
            this.mine1 = new GoLibrary.Mine();
            this.student1 = new GoLibrary.Student();
            this.findBookfrm1 = new GoLibrary.FindBookfrm();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::GoLibrary.Properties.Resources.tlo11;
            this.panel1.Controls.Add(this.logout);
            this.panel1.Controls.Add(this.wyp);
            this.panel1.Controls.Add(this.find);
            this.panel1.Controls.Add(this.dashboard);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(209, 600);
            this.panel1.TabIndex = 0;
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.logout.ForeColor = System.Drawing.Color.White;
            this.logout.Location = new System.Drawing.Point(0, 554);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(209, 34);
            this.logout.TabIndex = 4;
            this.logout.Text = "Wyloguj";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // wyp
            // 
            this.wyp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.wyp.FlatAppearance.BorderSize = 0;
            this.wyp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wyp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.wyp.ForeColor = System.Drawing.Color.White;
            this.wyp.Location = new System.Drawing.Point(0, 208);
            this.wyp.Name = "wyp";
            this.wyp.Size = new System.Drawing.Size(209, 34);
            this.wyp.TabIndex = 3;
            this.wyp.Text = "Moje wypozyczenia";
            this.wyp.UseVisualStyleBackColor = false;
            this.wyp.Click += new System.EventHandler(this.wyp_Click);
            // 
            // find
            // 
            this.find.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.find.FlatAppearance.BorderSize = 0;
            this.find.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.find.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.find.ForeColor = System.Drawing.Color.White;
            this.find.Location = new System.Drawing.Point(0, 168);
            this.find.Name = "find";
            this.find.Size = new System.Drawing.Size(209, 34);
            this.find.TabIndex = 2;
            this.find.Text = "Szukaj ksiazek";
            this.find.UseVisualStyleBackColor = false;
            this.find.Click += new System.EventHandler(this.find_Click);
            // 
            // dashboard
            // 
            this.dashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.dashboard.FlatAppearance.BorderSize = 0;
            this.dashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.dashboard.ForeColor = System.Drawing.Color.White;
            this.dashboard.Location = new System.Drawing.Point(0, 128);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(209, 34);
            this.dashboard.TabIndex = 1;
            this.dashboard.Text = "Student";
            this.dashboard.UseVisualStyleBackColor = false;
            this.dashboard.Click += new System.EventHandler(this.dashboard_Click);
            // 
            // mine1
            // 
            this.mine1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mine1.Location = new System.Drawing.Point(209, 0);
            this.mine1.Name = "mine1";
            this.mine1.Size = new System.Drawing.Size(808, 600);
            this.mine1.TabIndex = 3;
            this.mine1.Visible = false;
            // 
            // student1
            // 
            this.student1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.student1.Location = new System.Drawing.Point(209, 0);
            this.student1.Name = "student1";
            this.student1.Size = new System.Drawing.Size(808, 600);
            this.student1.TabIndex = 2;
            // 
            // findBookfrm1
            // 
            this.findBookfrm1.BackColor = System.Drawing.Color.White;
            this.findBookfrm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.findBookfrm1.Location = new System.Drawing.Point(209, 0);
            this.findBookfrm1.Name = "findBookfrm1";
            this.findBookfrm1.Size = new System.Drawing.Size(808, 600);
            this.findBookfrm1.TabIndex = 1;
            // 
            // UserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 600);
            this.Controls.Add(this.mine1);
            this.Controls.Add(this.student1);
            this.Controls.Add(this.findBookfrm1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UserForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserForm";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button dashboard;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Button wyp;
        private System.Windows.Forms.Button find;
        private FindBookfrm findBookfrm1;
        private Student student1;
        private Mine mine1;
    }
}