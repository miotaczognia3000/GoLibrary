﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GoLibrary
{
    public partial class Mine : UserControl
    {
        public static MySqlConnection conn = Funkcje.conn;
        public Mine()
        {
            InitializeComponent();
        }
        string state = "";
        string idbook1 = "";
        string idled1 = "";
        private void wypoGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.wypoGrid.Rows[e.RowIndex];
                idled1 = row.Cells[0].Value.ToString();
                idbook1 = row.Cells[5].Value.ToString();
                state = row.Cells[7].Value.ToString();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string querry;
            if (comboBoxled.Text == "Wydane")
                querry = $"SELECT * FROM leding WHERE login='{LogForm.logins}' AND state='wydano'";
            else if (comboBoxled.Text == "Oczekujące")
                querry = $"SELECT * FROM leding WHERE login='{LogForm.logins}' AND state='oczekujący'";
            else
                querry = $"SELECT * FROM leding WHERE login='{LogForm.logins}'";

            try
            {
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                wypoGrid.DataSource = ds.Tables[0];
                conn.Close();
                wypoGrid.Columns["id_book"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
                conn.Close();
            }
        }

        private void denButton_Click(object sender, EventArgs e)
        {
            if (state == "oczekujący")
            {
                if (idled1 == "" || idbook1 == "")
                    MessageBox.Show("Proszę zaznaczyć wiersz!");
                else if (Funkcje.deleteleding(idled1, idbook1))
                    MessageBox.Show("Anuluowano!");
                else
                    MessageBox.Show("Coś poszło nie tak :/");
            }
            else
                MessageBox.Show("Anuluować można tylko zamównia o stanie 'Oczekujący'!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
