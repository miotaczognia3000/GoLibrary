﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoLibrary
{
    public partial class AdminFrm : Form
    {
        public AdminFrm()
        {
            InitializeComponent();
        }

        private void AddBookButton_Click(object sender, EventArgs e)
        {
            addBookFrm1.Visible = true;
            requests1.Visible = false;
            zwrotyfrm1.Visible = false;
        }

        private void StudentsButton_Click(object sender, EventArgs e)
        {
            addBookFrm1.Visible = false;
            requests1.Visible = false;
            zwrotyfrm1.Visible = true;
        }

        private void wyp_Click(object sender, EventArgs e)
        {
            addBookFrm1.Visible = false;
            requests1.Visible = true;
            zwrotyfrm1.Visible = false;
        }

        private void logout_Click(object sender, EventArgs e)
        {
            new LogForm().Show();
            this.Hide();
        }
    }
}
