﻿
namespace GoLibrary
{
    partial class Requests
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Requests));
            this.reqDataGrid = new System.Windows.Forms.DataGridView();
            this.reqButton = new System.Windows.Forms.Button();
            this.searchButton1 = new System.Windows.Forms.Button();
            this.searchBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.reqDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // reqDataGrid
            // 
            this.reqDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reqDataGrid.Location = new System.Drawing.Point(3, 237);
            this.reqDataGrid.Name = "reqDataGrid";
            this.reqDataGrid.RowHeadersWidth = 51;
            this.reqDataGrid.RowTemplate.Height = 24;
            this.reqDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.reqDataGrid.Size = new System.Drawing.Size(802, 360);
            this.reqDataGrid.TabIndex = 0;
            this.reqDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.reqDataGrid_CellContentClick);
            // 
            // reqButton
            // 
            this.reqButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.reqButton.FlatAppearance.BorderSize = 0;
            this.reqButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.reqButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.reqButton.ForeColor = System.Drawing.Color.White;
            this.reqButton.Location = new System.Drawing.Point(668, 200);
            this.reqButton.Name = "reqButton";
            this.reqButton.Size = new System.Drawing.Size(137, 31);
            this.reqButton.TabIndex = 10;
            this.reqButton.Text = "Wypozycz";
            this.reqButton.UseVisualStyleBackColor = false;
            this.reqButton.Click += new System.EventHandler(this.reqButton_Click);
            // 
            // searchButton1
            // 
            this.searchButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.searchButton1.FlatAppearance.BorderSize = 0;
            this.searchButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.searchButton1.ForeColor = System.Drawing.Color.White;
            this.searchButton1.Location = new System.Drawing.Point(225, 200);
            this.searchButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchButton1.Name = "searchButton1";
            this.searchButton1.Size = new System.Drawing.Size(92, 31);
            this.searchButton1.TabIndex = 17;
            this.searchButton1.Text = "Szukaj";
            this.searchButton1.UseVisualStyleBackColor = false;
            this.searchButton1.Click += new System.EventHandler(this.searchButton1_Click);
            // 
            // searchBox1
            // 
            this.searchBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.searchBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.searchBox1.Font = new System.Drawing.Font("MS Reference Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.searchBox1.Location = new System.Drawing.Point(3, 200);
            this.searchBox1.Name = "searchBox1";
            this.searchBox1.Size = new System.Drawing.Size(216, 31);
            this.searchBox1.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(-2, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 27);
            this.label5.TabIndex = 15;
            this.label5.Text = "Login";
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(784, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 20);
            this.button1.TabIndex = 18;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Requests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.searchButton1);
            this.Controls.Add(this.searchBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.reqButton);
            this.Controls.Add(this.reqDataGrid);
            this.Name = "Requests";
            this.Size = new System.Drawing.Size(808, 600);
            this.Load += new System.EventHandler(this.Requests_Load);
            ((System.ComponentModel.ISupportInitialize)(this.reqDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView reqDataGrid;
        private System.Windows.Forms.Button reqButton;
        private System.Windows.Forms.Button searchButton1;
        private System.Windows.Forms.TextBox searchBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}
