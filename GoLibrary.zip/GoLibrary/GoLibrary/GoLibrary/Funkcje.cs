﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace GoLibrary
{
    class Funkcje
    {
        public static MySqlConnection conn = new MySqlConnection("server=127.0.0.1;uid=root;pwd=;database=biblioteka");
        
        public static bool login(string login, string pass)
        {
            string logquery = $"SELECT * FROM users WHERE login='{login}' AND password='{pass}';";
            MySqlCommand command = new MySqlCommand(logquery, conn);
            try
            {
                conn.Open();
                {

                    MySqlDataReader read = command.ExecuteReader();
                    if (read.Read())
                    {
                        read.Close();
                        conn.Close();
                        return true;
                    }
                    else
                    {
                        read.Close();
                        conn.Close();
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }
            

        }
        public static bool isthere(string login)
        {
            string checkquery = $"SELECT * FROM users WHERE login='{login}';";
            MySqlCommand command = new MySqlCommand(checkquery, conn);

            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }
            {

                MySqlDataReader read = command.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    conn.Close();
                    return true;
                }
                else
                {
                    read.Close();
                    conn.Close();
                    return false;
                }

            }

        }
        public static bool register(string name, string lname, string login, string pass)
        {
            string regquery = $"INSERT INTO users (id,name,lastname,login,password) VALUES ('', '{name}', '{lname}','{login}', '{pass}');";
            MySqlCommand command = new MySqlCommand(regquery, conn);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }

        }
        public static bool findbook(string title, string name, string lname)
        {
            string querry;
            #region ściana płaczu v.2
            if (title != "" && name == "" && lname == "")
            {
                 querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND statebook='1' GROUP BY title";
            }
            else if (title == "" && name != "" && lname == "")
            {
                querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE author_name LIKE '%{name}%' AND statebook='1' GROUP BY title";
            }
            else if (title == "" && name == "" && lname != "")
            {
                querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
            }
            else if (title == "" && name != "" && lname != "")
            {
                querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE author_name LIKE '%{name}%' AND author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
            }
            else if (title != "" && name != "" && lname == "")
            {
                querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND author_name LIKE '%{name}%' AND statebook='1' GROUP BY title";
            }
            else if (title != "" && name == "" && lname != "")
            {
                querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
            }
            else
            {
                querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND author_name LIKE '%{name}%'AND author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
            }
            #endregion
            MySqlCommand command = new MySqlCommand(querry, conn);
            conn.Open();
            MySqlDataReader read = command.ExecuteReader();
                if (read.Read())
                {
                    read.Close();
                    conn.Close();
                    return true;
                }
                else
                {
                    read.Close();
                    conn.Close();
                    return false;
                }
        }
        public static string myname(string login)
        {
            string uid;
            string querry = $"SELECT name FROM users WHERE login='{login}';";
            MySqlCommand command = new MySqlCommand(querry, conn);
            
            try
            {
                conn.Open();
                MySqlDataReader read = command.ExecuteReader();
                read.Read();
                uid = read.GetString(0);
                conn.Close();
                return uid;
            }
            catch(Exception ex)
            {
                conn.Close();
                return "ZALOGUJ SIĘ JESZCZE RAZ";
            }

        }
        public static string mylastname(string login)
        {
            string uid;
            string querry = $"SELECT lastname FROM users WHERE login='{login}';";
            MySqlCommand command = new MySqlCommand(querry, conn);

            try
            {
                conn.Open();
                MySqlDataReader read = command.ExecuteReader();
                read.Read();
                uid = read.GetString(0);
                conn.Close();
                return uid;
            }
            catch (Exception ex)
            {
                conn.Close();
                return "ZALOGUJ SIĘ JESZCZE RAZ";
            }

        }
        public static bool leding(string name, string lastname, string title, string idbook)
        {
            string regquery = $"INSERT INTO leding (id_leding,login,name,lastName,title,id_book,state) VALUES ('','{LogForm.logins}', '{name}', '{lastname}','{title}', '{idbook}', 'oczekujący');";
            string upquery = $"UPDATE books SET statebook='0' WHERE id_book='{idbook}'";
            MySqlCommand command = new MySqlCommand(regquery, conn);
            MySqlCommand upcommand = new MySqlCommand(upquery, conn);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                upcommand.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }
        }
        public static bool updateleding(string idled)
        {
            if (idled == "")
                return false;
            string regquery = $"UPDATE leding SET state='wydano' WHERE id_leding='{idled}'";
            MySqlCommand command = new MySqlCommand(regquery, conn);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }
        }
        public static bool deleteleding(string idled, string idbook)
        {
            if (idled == "")
                return false;
            string regquery = $"DELETE FROM leding WHERE id_leding='{idled}'";
            string query = $"UPDATE books SET statebook='1' WHERE id_book='{idbook}'";
            MySqlCommand command = new MySqlCommand(regquery, conn);
            MySqlCommand command2 = new MySqlCommand(query, conn);
            conn.Open();
            try
            {
                command2.ExecuteNonQuery();
                command.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }
        }
        public static bool addbook(string title, string name, string lname, string sect)
        {
            string addquery = $"INSERT INTO books (id_book,title,author_name,author_lastname,section,statebook) VALUES ('', '{title}', '{name}','{lname}', '{sect}','1');";
            MySqlCommand command = new MySqlCommand(addquery, conn);
            conn.Open();
            try
            {
                command.ExecuteNonQuery();
                conn.Close();
                return true;
            }
            catch (Exception ex)
            {
                conn.Close();
                return false;
            }
        }


    }
        
}
